package com.cts.springmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
