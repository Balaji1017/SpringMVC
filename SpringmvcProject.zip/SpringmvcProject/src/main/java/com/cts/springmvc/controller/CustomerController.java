package com.cts.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.springmvc.entity.Customer;
import com.cts.springmvc.services.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	public CustomerService service;

	@GetMapping("/table")
	public String modelpage(Model model) {
		model.addAttribute("customers", service.getCustomers());
		return "table";
	}
	@GetMapping("/showNewCustomer")
	public String showNewCustomer(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer", customer);
		return "new";
	}
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") Customer customer) {
		service.saveCustomer(customer);
		return "redirect:/table";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value="id") int id,Model model) {
		Customer customer=service.getCustomerByID(id);
		model.addAttribute("customer", customer);
		return "update";
		
	}
	
	@GetMapping("/deleteCustomer/{id}")
	public String deleteCustomer(@PathVariable(value="id") int id,Model model) {
		this.service.deleteCustomer(id);
		return "redirect:/table";
		
	}
}

