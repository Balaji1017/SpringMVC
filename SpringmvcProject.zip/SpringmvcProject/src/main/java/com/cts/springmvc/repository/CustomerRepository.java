package com.cts.springmvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.springmvc.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
	Customer findByName(String name);

	Customer findByCity(String city);
	
	Customer findByContact(String contact);
	
	Customer findByEmail(String email);
}
