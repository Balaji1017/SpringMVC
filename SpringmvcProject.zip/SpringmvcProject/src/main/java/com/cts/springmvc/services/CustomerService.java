package com.cts.springmvc.services;

import java.util.List;
import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springmvc.entity.Customer;
import com.cts.springmvc.repository.CustomerRepository;



@Service
public class CustomerService {
	
	@Autowired
	public CustomerRepository repository;
	
	
	//get methods
	public Customer getCustomerByID(int id) {
		Optional<Customer> optional = repository.findById(id);
		Customer customer= null;
		if (optional.isPresent()) {
			customer = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for id :: " + id);
		}
		return customer;
	}

	public Customer getCustomerByName(String name) {
		Optional<Customer> optional = Optional.of(repository.findByName(name));
		Customer customer= null;
		if (optional.isPresent()) {
			customer = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for name :: " + name);
		}
		return customer;
	}

	public Customer getCustomerByCity(String city) {
		Optional<Customer> optional = Optional.of(repository.findByCity(city));
		Customer customer= null;
		if (optional.isPresent()) {
			customer = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for city :: " + city);
		}
		return customer;
	}
	
	public List<Customer> getCustomers(){
		return repository.findAll();
	}
	
	//put methods
	public Customer updateCustomer(Customer customer) {
		Customer existingCustomer = repository.findById(customer.getId()).orElse(null);

		existingCustomer.setName(customer.getName());
		existingCustomer.setCity(customer.getCity());
		existingCustomer.setContact(customer.getContact());
		existingCustomer.setEmail(customer.getEmail());
		return repository.save(existingCustomer);
	}
	
	//delete methods
	public void deleteCustomer(int id) {
		this.repository.deleteById(id);
		
	}
	
	//post methods
	public Customer saveCustomer(Customer customer) {
		return repository.save(customer);
	}

	public List<Customer> saveCustomers(List<Customer> customers) {
		return repository.saveAll(customers);
	}
}
